
export interface DiaryPost {
    _id?: string;
    text: string;
    date: string;
}