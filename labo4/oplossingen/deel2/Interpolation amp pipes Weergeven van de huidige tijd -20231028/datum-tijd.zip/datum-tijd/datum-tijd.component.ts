import { Component } from '@angular/core';

@Component({
  selector: 'app-datum-tijd',
  templateUrl: './datum-tijd.component.html',
  styleUrls: ['./datum-tijd.component.css']
})
export class DatumTijdComponent {

  datum: Date;

  constructor() {
    setInterval(() => this.datum = new Date(), 1000)
  }
}
