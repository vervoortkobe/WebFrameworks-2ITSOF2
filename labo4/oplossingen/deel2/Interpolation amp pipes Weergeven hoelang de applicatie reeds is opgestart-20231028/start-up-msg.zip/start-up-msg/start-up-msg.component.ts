import { Component, OnInit } from '@angular/core';
import * as moment from "moment"
// Door deze import toe te voegen worden alle boodschappen van moment in het nederlands weergegeven
// zonder deze import worden de teksten in het Engels weergegeven. 
import 'moment/locale/nl';

@Component({
  selector: 'app-start-up-msg',
  templateUrl: './start-up-msg.component.html',
  styleUrls: ['./start-up-msg.component.css']
})
export class StartUpMsgComponent {

  message: string;
  //we noteren de starttijd, zodat we steeds kunnen bepalen hoelang geleden deze werd gestart
  start : Date = new Date();

  constructor() {
    //Om sneller te kunnen testen alsof de applicatie reeds een tijdje is opgestart
    //zetten we de tijd even achteruit met een aantal minuten
    //gebruik dan deze lijn code
    // this.start = moment(this.start).subtract(120, 'minutes').toDate();

     this.UpdateMessage();
     setInterval(this.UpdateMessage, 1000)
   }

   UpdateMessage = () => {
    //De fromNow functie van moment.js zal een boodschap geven hoelang geleden de gegeven datum 
    //is ten opzicht van nu.
    this.message = moment(this.start).fromNow();
   }
}
