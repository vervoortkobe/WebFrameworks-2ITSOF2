import { Component, OnInit } from '@angular/core';
import * as _ from "lodash"

@Component({
  selector: 'app-random-value',
  templateUrl: './random-value.component.html',
  styleUrls: ['./random-value.component.css']
})
export class RandomValueComponent {

  random: number;

  constructor() {
    //Bij de opstart willen we reeds een eerst willekeurige waarde
    this.ChooseNewValue();
    //vervolgens om de 2 seconden terug een andere waarde
    setInterval(this.ChooseNewValue, 2000)
  }

  ChooseNewValue = () => this.random = _.random(1, 100);

}
