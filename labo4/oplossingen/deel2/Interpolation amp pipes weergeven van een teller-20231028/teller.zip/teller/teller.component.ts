import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teller',
  templateUrl: './teller.component.html',
  styleUrls: ['./teller.component.css']
})
export class TellerComponent implements OnInit {
  teller: number = 1;
  teller2: number = 1;

  constructor() {
    setInterval(() => this.teller++, 1000)
    setInterval(() => this.teller2++, 200)
   }

  ngOnInit() {
  }

}
