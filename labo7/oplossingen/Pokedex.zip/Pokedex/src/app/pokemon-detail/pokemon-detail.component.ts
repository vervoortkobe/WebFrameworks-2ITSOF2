import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import pokemon from '../pokemon.json';
import { Pokemon } from '../types';

@Component({
  selector: 'app-pokemon-detail',
  templateUrl: './pokemon-detail.component.html',
  styleUrls: ['./pokemon-detail.component.css']
})
export class PokemonDetailComponent implements OnInit {

  pokemon: Pokemon[] = pokemon;
  selectedPokemon: Pokemon | undefined;

  constructor(private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      let id = params.get("id")!;
      this.selectedPokemon = this.pokemon.find(p => p.id === id);
    })
  }

}
