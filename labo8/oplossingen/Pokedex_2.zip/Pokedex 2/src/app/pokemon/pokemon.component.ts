import { Component, OnInit } from '@angular/core';
import { PokedexService } from '../pokedex.service';

@Component({
  selector: 'app-pokemon',
  templateUrl: './pokemon.component.html',
  styleUrls: ['./pokemon.component.css']
})
export class PokemonComponent implements OnInit {

  constructor(private pokedex: PokedexService) { }

  ngOnInit(): void {
  }

  public get Pokemon() {
    return this.pokedex.Pokemon;
  }

  public favorite(id: number) {
    this.pokedex.favorite(id);
  }

}
