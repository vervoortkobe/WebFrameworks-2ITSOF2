import { Injectable } from '@angular/core';
import pokemon from './pokemon.json';
import Pokemon from './types';

@Injectable({
  providedIn: 'root'
})
export class PokedexService {

  constructor() { }

  public get Pokemon(): Pokemon[] {
    return pokemon;
  }

  public getPokemonById(id: number): Pokemon | undefined {
    return pokemon.find(pokemon => parseInt(pokemon.id) === id);
  }

  public favorite(id: number) {
    let pokemon = this.getPokemonById(id);
    if (pokemon) {
      pokemon.favorite = !pokemon.favorite;
    }
  }

}
