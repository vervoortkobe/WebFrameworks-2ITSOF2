import { Kunstenaar } from '../entities/kunstenaar.entity';

export class CreateKunstenaarDto extends Kunstenaar {}
