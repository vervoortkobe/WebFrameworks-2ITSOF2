export class Kunstenaar {
  Voornaam: string;
  Familienaam: string;
  Geboorte_gegevens: string;
  Overlijden_gegevens: string;
  Locatie_activiteit: string;
  Biografie: string;
  Activiteiten: string;
}
