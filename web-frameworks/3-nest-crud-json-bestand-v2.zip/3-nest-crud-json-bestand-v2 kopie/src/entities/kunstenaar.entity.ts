export class Kunstenaar {
  id: number;
  voornaam: string;
  familienaam: string;
  geboorte_gegevens: string;
  overlijden_gegevens: string;
  locatie_activiteit: string;
  biografie: string;
  activiteiten: string;
}
