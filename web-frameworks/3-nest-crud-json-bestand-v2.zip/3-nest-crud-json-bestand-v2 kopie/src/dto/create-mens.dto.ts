import { Mens } from '../entities/mens.entity';

export class CreateMensDto extends Mens {}
