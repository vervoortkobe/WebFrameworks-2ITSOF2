import { Logger } from "./logging";

let l = new Logger();

while (true) {
    l.logDateSlow();
}