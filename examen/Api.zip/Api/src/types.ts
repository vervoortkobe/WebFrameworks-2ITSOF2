export interface Score {
    id?: string;
    position: number;
    username: string;
    score: number;
    date: string;
}