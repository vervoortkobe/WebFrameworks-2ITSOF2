export class Mens {
  id: number;
  naam: string;
  leeftijd: number;
}
